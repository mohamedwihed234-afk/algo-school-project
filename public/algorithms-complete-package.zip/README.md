# المنصة التفاعلية المتقدمة لفهم وهندسة الخوارزميات المنطقية
مدرسة الوصال العامرة - بإشراف الأستاذ حمزة

## النشر الفوري بنقرة واحدة على Cloudflare Pages:
1. ارفع مجلد `dist` مباشرة عبر **Cloudflare Dashboard -> Workers & Pages -> Upload Assets**.
2. أو اربط مستودع GitHub مع إعدادات البناء:
   - Framework preset: **Vite**
   - Build command: `npm run build`
   - Build output directory: `dist`

## النشر الفوري بنقرة واحدة على Netlify:
1. ادخل إلى **app.netlify.com/drop**.
2. اسحب مجلد `dist` مباشرة وأفلته في المتصفح وسيعمل الموقع فوراً برابط عالمي!

## إعداد قاعدة بيانات Supabase:
تم ربط المشروع مسبقاً بعنوان المشروع ومفتاح الوصول.
قم بنسخ ما بداخل ملف `supabase_schema.sql` والصقه في **Supabase SQL Editor** ثم اضغط **RUN**.
